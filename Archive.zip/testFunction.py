from datetime import datetime
from datetime import time

target = 1561335694
now = datetime.now()
unixtime = time.(now.time())
print(unixtime)
