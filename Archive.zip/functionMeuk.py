from getUserCreds import user_creds

uname, pwd = user_creds()
print("loosername = ", uname)
print("geheim ding = ", pwd)

